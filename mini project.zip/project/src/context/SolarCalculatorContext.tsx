import React, { createContext, useContext, useState, ReactNode } from 'react';

// Solar panel efficiency by region (kWh per square meter per year)
const REGION_EFFICIENCY: Record<string, number> = {
  'North America': 1600,
  'Europe': 1400,
  'Asia': 1500,
  'Australia': 1800,
  'Africa': 2000,
  'South America': 1700,
};

// Installation cost per watt by region (USD)
const INSTALLATION_COST: Record<string, number> = {
  'North America': 2.8,
  'Europe': 3.0,
  'Asia': 2.0,
  'Australia': 2.6,
  'Africa': 2.2,
  'South America': 2.4,
};

// Standard solar panel dimensions (in meters)
const PANEL_WIDTH = 1.7;
const PANEL_HEIGHT = 1.0;
const PANEL_AREA = PANEL_WIDTH * PANEL_HEIGHT;
const PANEL_WATTAGE = 350; // Watts per panel

interface SolarCalculatorContextType {
  surfaceArea: number;
  setSurfaceArea: (area: number) => void;
  buildingType: string;
  setBuildingType: (type: string) => void;
  region: string;
  setRegion: (region: string) => void;
  sunlightHours: number;
  setSunlightHours: (hours: number) => void;
  roofAngle: number;
  setRoofAngle: (angle: number) => void;
  panelCount: number;
  annualEnergy: number;
  installationCost: number;
  calculateResults: () => void;
  paybackPeriod: number;
  co2Reduction: number;
  availableRegions: string[];
  buildingTypes: string[];
  resetForm: () => void;
}

const defaultContextValue: SolarCalculatorContextType = {
  surfaceArea: 0,
  setSurfaceArea: () => {},
  buildingType: 'Residential',
  setBuildingType: () => {},
  region: 'North America',
  setRegion: () => {},
  sunlightHours: 5,
  setSunlightHours: () => {},
  roofAngle: 30,
  setRoofAngle: () => {},
  panelCount: 0,
  annualEnergy: 0,
  installationCost: 0,
  calculateResults: () => {},
  paybackPeriod: 0,
  co2Reduction: 0,
  availableRegions: Object.keys(REGION_EFFICIENCY),
  buildingTypes: ['Residential', 'Commercial', 'Restaurant', 'Industrial'],
  resetForm: () => {},
};

const SolarCalculatorContext = createContext<SolarCalculatorContextType>(defaultContextValue);

export const useSolarCalculator = () => useContext(SolarCalculatorContext);

interface SolarCalculatorProviderProps {
  children: ReactNode;
}

export const SolarCalculatorProvider: React.FC<SolarCalculatorProviderProps> = ({ children }) => {
  const [surfaceArea, setSurfaceArea] = useState<number>(0);
  const [buildingType, setBuildingType] = useState<string>('Residential');
  const [region, setRegion] = useState<string>('North America');
  const [sunlightHours, setSunlightHours] = useState<number>(5);
  const [roofAngle, setRoofAngle] = useState<number>(30);
  
  const [panelCount, setPanelCount] = useState<number>(0);
  const [annualEnergy, setAnnualEnergy] = useState<number>(0);
  const [installationCost, setInstallationCost] = useState<number>(0);
  const [paybackPeriod, setPaybackPeriod] = useState<number>(0);
  const [co2Reduction, setCo2Reduction] = useState<number>(0);

  const calculateResults = () => {
    // Calculate number of panels that can fit
    const usableSurfaceArea = surfaceArea * 0.8; // 80% of surface is usable
    const calculatedPanelCount = Math.floor(usableSurfaceArea / PANEL_AREA);
    
    // Calculate energy output
    const efficiency = REGION_EFFICIENCY[region] || 1500;
    const angleEfficiency = calculateAngleEfficiency(roofAngle);
    const totalWattage = calculatedPanelCount * PANEL_WATTAGE;
    const dailyEnergy = (totalWattage / 1000) * sunlightHours * angleEfficiency;
    const calculatedAnnualEnergy = dailyEnergy * 365;
    
    // Calculate installation cost
    const costPerWatt = INSTALLATION_COST[region] || 2.5;
    const calculatedInstallationCost = totalWattage * costPerWatt;
    
    // Calculate payback period (assuming electricity cost of $0.15 per kWh)
    const annualSavings = calculatedAnnualEnergy * 0.15;
    const calculatedPaybackPeriod = annualSavings > 0 
      ? calculatedInstallationCost / annualSavings 
      : 0;
    
    // Calculate CO2 reduction (0.85 kg CO2 per kWh of solar energy)
    const calculatedCo2Reduction = calculatedAnnualEnergy * 0.85;
    
    setPanelCount(calculatedPanelCount);
    setAnnualEnergy(calculatedAnnualEnergy);
    setInstallationCost(calculatedInstallationCost);
    setPaybackPeriod(calculatedPaybackPeriod);
    setCo2Reduction(calculatedCo2Reduction);
  };

  const calculateAngleEfficiency = (angle: number): number => {
    // Optimal angle is around 30-40 degrees
    if (angle >= 25 && angle <= 45) {
      return 1.0; // 100% efficiency
    } else if (angle >= 15 && angle < 25) {
      return 0.9; // 90% efficiency
    } else if (angle > 45 && angle <= 60) {
      return 0.85; // 85% efficiency
    } else {
      return 0.75; // 75% efficiency for other angles
    }
  };

  const resetForm = () => {
    setSurfaceArea(0);
    setBuildingType('Residential');
    setRegion('North America');
    setSunlightHours(5);
    setRoofAngle(30);
    setPanelCount(0);
    setAnnualEnergy(0);
    setInstallationCost(0);
    setPaybackPeriod(0);
    setCo2Reduction(0);
  };

  const value = {
    surfaceArea,
    setSurfaceArea,
    buildingType,
    setBuildingType,
    region,
    setRegion,
    sunlightHours,
    setSunlightHours,
    roofAngle,
    setRoofAngle,
    panelCount,
    annualEnergy,
    installationCost,
    calculateResults,
    paybackPeriod,
    co2Reduction,
    availableRegions: Object.keys(REGION_EFFICIENCY),
    buildingTypes: ['Residential', 'Commercial', 'Restaurant', 'Industrial'],
    resetForm,
  };

  return (
    <SolarCalculatorContext.Provider value={value}>
      {children}
    </SolarCalculatorContext.Provider>
  );
};