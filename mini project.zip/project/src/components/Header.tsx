import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <Sun className="h-8 w-8 text-teal-600" />
            <span className="font-bold text-xl text-gray-800">SolarCalc</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <NavLink to="/" currentPath={location.pathname}>Home</NavLink>
            <NavLink to="/calculator" currentPath={location.pathname}>Calculator</NavLink>
            <NavLink to="/about" currentPath={location.pathname}>About</NavLink>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700 focus:outline-none" 
            onClick={toggleMobileMenu}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg mt-2 px-4 py-3 animate-fadeIn">
          <div className="flex flex-col space-y-3">
            <MobileNavLink to="/" currentPath={location.pathname} onClick={toggleMobileMenu}>Home</MobileNavLink>
            <MobileNavLink to="/calculator" currentPath={location.pathname} onClick={toggleMobileMenu}>Calculator</MobileNavLink>
            <MobileNavLink to="/about" currentPath={location.pathname} onClick={toggleMobileMenu}>About</MobileNavLink>
          </div>
        </div>
      )}
    </header>
  );
};

interface NavLinkProps {
  to: string;
  currentPath: string;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, currentPath, children }) => {
  const isActive = to === '/' ? currentPath === '/' : currentPath.startsWith(to);
  
  return (
    <Link 
      to={to} 
      className={`font-medium transition-colors duration-200 ${
        isActive 
          ? 'text-teal-600 border-b-2 border-teal-600' 
          : 'text-gray-600 hover:text-teal-600'
      }`}
    >
      {children}
    </Link>
  );
};

interface MobileNavLinkProps extends NavLinkProps {
  onClick: () => void;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, currentPath, onClick, children }) => {
  const isActive = to === '/' ? currentPath === '/' : currentPath.startsWith(to);
  
  return (
    <Link 
      to={to} 
      className={`font-medium py-2 px-3 rounded-md block transition-colors duration-200 ${
        isActive 
          ? 'text-white bg-teal-600' 
          : 'text-gray-600 hover:text-teal-600 hover:bg-gray-100'
      }`}
      onClick={onClick}
    >
      {children}
    </Link>
  );
};

export default Header;