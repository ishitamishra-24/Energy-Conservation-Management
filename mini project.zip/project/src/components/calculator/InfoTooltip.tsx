import React, { useState } from 'react';
import { Info } from 'lucide-react';

interface InfoTooltipProps {
  content: string;
}

const InfoTooltip: React.FC<InfoTooltipProps> = ({ content }) => {
  const [isVisible, setIsVisible] = useState(false);
  
  return (
    <div className="relative inline-block">
      <button
        type="button"
        className="text-gray-400 hover:text-teal-500 transition-colors"
        onMouseEnter={() => setIsVisible(true)}
        onMouseLeave={() => setIsVisible(false)}
        onClick={(e) => {
          e.preventDefault();
          setIsVisible(!isVisible);
        }}
      >
        <Info size={16} />
      </button>
      
      {isVisible && (
        <div className="absolute z-10 w-64 p-3 mt-2 -translate-x-1/2 left-1/2 transform bg-gray-800 rounded-md shadow-lg text-white text-sm">
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 transform w-0 h-0 border-l-8 border-r-8 border-b-8 border-transparent border-b-gray-800"></div>
          {content}
        </div>
      )}
    </div>
  );
};

export default InfoTooltip;