import React, { ReactNode } from 'react';

interface CalculatorLayoutProps {
  children: ReactNode;
}

const CalculatorLayout: React.FC<CalculatorLayoutProps> = ({ children }) => {
  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md p-6 md:p-8">
          {children}
        </div>
      </div>
    </div>
  );
};

export default CalculatorLayout;