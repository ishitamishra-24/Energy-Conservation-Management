import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface ResultsChartProps {
  costData: number[];
  savingsData: number[];
}

const ResultsChart: React.FC<ResultsChartProps> = ({ costData, savingsData }) => {
  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Cost vs. Savings Over Time',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '$' + value.toLocaleString();
          }
        }
      }
    },
  };

  // Fill the cost array for all years with the installation cost
  const fullCostData = Array(25).fill(costData[0]);
  
  const labels = Array.from({ length: 25 }, (_, i) => `Year ${i + 1}`);

  const data = {
    labels,
    datasets: [
      {
        label: 'Initial Cost',
        data: fullCostData,
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.5)',
      },
      {
        label: 'Cumulative Savings',
        data: savingsData,
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.5)',
      },
    ],
  };

  return <Line options={options} data={data} />;
};

export default ResultsChart;