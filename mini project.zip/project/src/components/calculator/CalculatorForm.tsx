import React from 'react';
import { useSolarCalculator } from '../../context/SolarCalculatorContext';
import { Info } from 'lucide-react';
import InfoTooltip from './InfoTooltip';

interface CalculatorFormProps {
  onSubmit: () => void;
}

const CalculatorForm: React.FC<CalculatorFormProps> = ({ onSubmit }) => {
  const {
    surfaceArea,
    setSurfaceArea,
    buildingType,
    setBuildingType,
    region,
    setRegion,
    sunlightHours,
    setSunlightHours,
    roofAngle,
    setRoofAngle,
    buildingTypes,
    availableRegions,
  } = useSolarCalculator();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Building Type */}
        <div className="form-group">
          <label htmlFor="buildingType" className="form-label">
            Building Type
          </label>
          <select
            id="buildingType"
            value={buildingType}
            onChange={(e) => setBuildingType(e.target.value)}
            className="form-select"
            required
          >
            {buildingTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* Surface Area */}
        <div className="form-group">
          <div className="flex items-center space-x-2">
            <label htmlFor="surfaceArea" className="form-label">
              Available Surface Area (m²)
            </label>
            <InfoTooltip 
              content="The total area available for solar panel installation, typically roof surface area."
            />
          </div>
          <input
            type="number"
            id="surfaceArea"
            value={surfaceArea || ''}
            onChange={(e) => setSurfaceArea(Number(e.target.value))}
            placeholder="Enter area in square meters"
            className="form-input"
            min="1"
            required
          />
        </div>

        {/* Region */}
        <div className="form-group">
          <div className="flex items-center space-x-2">
            <label htmlFor="region" className="form-label">
              Region
            </label>
            <InfoTooltip 
              content="Your geographical region affects solar efficiency and installation costs."
            />
          </div>
          <select
            id="region"
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="form-select"
            required
          >
            {availableRegions.map((regionOption) => (
              <option key={regionOption} value={regionOption}>
                {regionOption}
              </option>
            ))}
          </select>
        </div>

        {/* Sunlight Hours */}
        <div className="form-group">
          <div className="flex items-center space-x-2">
            <label htmlFor="sunlightHours" className="form-label">
              Average Daily Sunlight Hours
            </label>
            <InfoTooltip 
              content="The average number of peak sunlight hours your location receives daily."
            />
          </div>
          <div className="flex items-center">
            <input
              type="range"
              id="sunlightHours"
              value={sunlightHours}
              onChange={(e) => setSunlightHours(Number(e.target.value))}
              min="2"
              max="8"
              step="0.5"
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <span className="ml-4 w-10 text-center font-medium">{sunlightHours}</span>
          </div>
        </div>

        {/* Roof Angle */}
        <div className="form-group md:col-span-2">
          <div className="flex items-center space-x-2">
            <label htmlFor="roofAngle" className="form-label">
              Roof Angle (degrees)
            </label>
            <InfoTooltip 
              content="The angle of your roof affects solar panel efficiency. Optimal angles are typically between 30-40 degrees."
            />
          </div>
          <div className="flex items-center">
            <input
              type="range"
              id="roofAngle"
              value={roofAngle}
              onChange={(e) => setRoofAngle(Number(e.target.value))}
              min="0"
              max="60"
              step="5"
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <span className="ml-4 w-10 text-center font-medium">{roofAngle}°</span>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-6">
        <button
          type="submit"
          className="btn-primary w-full md:w-auto px-8 py-4"
        >
          Calculate Solar Potential
        </button>
      </div>
    </form>
  );
};

export default CalculatorForm;