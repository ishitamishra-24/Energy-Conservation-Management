import React from 'react';

interface ResultItem {
  label: string;
  value: string;
}

interface ResultsSummaryProps {
  items: ResultItem[];
}

const ResultsSummary: React.FC<ResultsSummaryProps> = ({ items }) => {
  return (
    <div className="divide-y divide-gray-200">
      {items.map((item, index) => (
        <div key={index} className="py-3 flex justify-between">
          <span className="text-gray-600">{item.label}</span>
          <span className="font-medium text-gray-900">{item.value}</span>
        </div>
      ))}
    </div>
  );
};

export default ResultsSummary;