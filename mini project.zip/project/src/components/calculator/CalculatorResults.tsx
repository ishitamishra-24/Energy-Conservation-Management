import React from 'react';
import { useSolarCalculator } from '../../context/SolarCalculatorContext';
import { ArrowLeft, Download } from 'lucide-react';
import ResultsChart from './ResultsChart';
import ResultsSummary from './ResultsSummary';

interface CalculatorResultsProps {
  onReset: () => void;
}

const CalculatorResults: React.FC<CalculatorResultsProps> = ({ onReset }) => {
  const { 
    buildingType,
    region,
    surfaceArea,
    panelCount,
    annualEnergy,
    installationCost,
    paybackPeriod,
    co2Reduction
  } = useSolarCalculator();

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const handleDownloadPDF = () => {
    alert('PDF download functionality would be implemented here');
    // In a real implementation, this would generate and download a PDF report
  };

  return (
    <div className="space-y-8">
      <div className="bg-teal-50 border-l-4 border-teal-500 p-4 rounded-r-md">
        <h2 className="text-2xl md:text-3xl font-bold text-teal-800 mb-2">
          Your Solar Calculation Results
        </h2>
        <p className="text-teal-700">
          Based on a {surfaceArea} m² {buildingType.toLowerCase()} property in {region}.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">System Requirements</h3>
          
          <ResultsSummary 
            items={[
              { label: 'Recommended Solar Panels', value: `${panelCount} panels` },
              { label: 'Total System Size', value: `${((panelCount * 350) / 1000).toFixed(1)} kW` },
              { label: 'Roof Area Needed', value: `${(panelCount * 1.7).toFixed(1)} m²` },
              { label: 'Roof Space Utilization', value: `${Math.min(100, Math.round((panelCount * 1.7 * 100) / surfaceArea))}%` }
            ]}
          />
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Energy Production</h3>
          
          <ResultsSummary 
            items={[
              { label: 'Annual Energy Production', value: `${Math.round(annualEnergy).toLocaleString()} kWh` },
              { label: 'Monthly Average', value: `${Math.round(annualEnergy / 12).toLocaleString()} kWh` },
              { label: 'Daily Average', value: `${Math.round(annualEnergy / 365).toLocaleString()} kWh` },
              { label: 'CO₂ Reduction', value: `${Math.round(co2Reduction).toLocaleString()} kg/year` }
            ]}
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Financial Overview</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <ResultsSummary 
              items={[
                { label: 'Estimated Installation Cost', value: formatCurrency(installationCost) },
                { label: 'Cost per Watt', value: `$${(installationCost / (panelCount * 350)).toFixed(2)}/W` },
                { label: 'Estimated Annual Savings', value: formatCurrency(annualEnergy * 0.15) },
                { label: 'Payback Period', value: `${paybackPeriod.toFixed(1)} years` }
              ]}
            />
          </div>
          
          <div className="h-64">
            <ResultsChart 
              costData={[installationCost]} 
              savingsData={Array.from({ length: 25 }, (_, i) => (annualEnergy * 0.15) * (i + 1))}
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
        <button
          onClick={onReset}
          className="btn-secondary flex items-center"
        >
          <ArrowLeft className="mr-2 h-5 w-5" /> Back to Calculator
        </button>
        
        <button
          onClick={handleDownloadPDF}
          className="btn-primary flex items-center"
        >
          <Download className="mr-2 h-5 w-5" /> Download Report
        </button>
      </div>
    </div>
  );
};

export default CalculatorResults;