import React from 'react';
import { Link } from 'react-router-dom';
import { Sun, Github, Twitter, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gradient-to-br from-gray-800 to-gray-900 text-white pt-12 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Sun className="h-6 w-6 text-teal-400" />
              <span className="font-bold text-lg">SolarCalc</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Helping you make informed decisions about solar energy for your property with accurate calculations and personalized recommendations.
            </p>
            <div className="flex space-x-4">
              <SocialLink icon={<Twitter className="h-5 w-5" />} href="https://twitter.com" />
              <SocialLink icon={<Linkedin className="h-5 w-5" />} href="https://linkedin.com" />
              <SocialLink icon={<Github className="h-5 w-5" />} href="https://github.com" />
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink href="/">Home</FooterLink>
              <FooterLink href="/calculator">Calculator</FooterLink>
              <FooterLink href="/about">About</FooterLink>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Resources</h3>
            <ul className="space-y-2">
              <FooterLink href="#">Solar Panel Guide</FooterLink>
              <FooterLink href="#">Energy Saving Tips</FooterLink>
              <FooterLink href="#">Installation FAQ</FooterLink>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3 text-gray-300 hover:text-white transition duration-200">
                <Mail className="h-5 w-5 mt-0.5 flex-shrink-0 text-teal-400" />
                <span>info@solarcalc.com</span>
              </li>
              <li className="flex items-start space-x-3 text-gray-300 hover:text-white transition duration-200">
                <Phone className="h-5 w-5 mt-0.5 flex-shrink-0 text-teal-400" />
                <span>+1 (888) 555-SOLAR</span>
              </li>
              <li className="flex items-start space-x-3 text-gray-300 hover:text-white transition duration-200">
                <MapPin className="h-5 w-5 mt-0.5 flex-shrink-0 text-teal-400" />
                <span>Solar City, Earth</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {currentYear} SolarCalc. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <Link to="#" className="text-gray-400 hover:text-teal-400 text-sm transition duration-200">Privacy Policy</Link>
              <Link to="#" className="text-gray-400 hover:text-teal-400 text-sm transition duration-200">Terms of Service</Link>
              <Link to="#" className="text-gray-400 hover:text-teal-400 text-sm transition duration-200">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface SocialLinkProps {
  icon: React.ReactNode;
  href: string;
}

const SocialLink: React.FC<SocialLinkProps> = ({ icon, href }) => {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-gray-700 hover:bg-teal-600 p-2 rounded-full transition-all duration-300 text-white hover:scale-110"
    >
      {icon}
    </a>
  );
};

interface FooterLinkProps {
  href: string;
  children: React.ReactNode;
}

const FooterLink: React.FC<FooterLinkProps> = ({ href, children }) => {
  return (
    <li>
      <Link 
        to={href} 
        className="text-gray-300 hover:text-teal-400 transition duration-200"
      >
        {children}
      </Link>
    </li>
  );
};

export default Footer;