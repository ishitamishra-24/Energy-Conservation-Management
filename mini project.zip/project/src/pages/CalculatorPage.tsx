import React, { useState } from 'react';
import { useSolarCalculator } from '../context/SolarCalculatorContext';
import CalculatorForm from '../components/calculator/CalculatorForm';
import CalculatorResults from '../components/calculator/CalculatorResults';
import CalculatorLayout from '../components/calculator/CalculatorLayout';

const CalculatorPage: React.FC = () => {
  const [showResults, setShowResults] = useState(false);
  const { calculateResults, resetForm } = useSolarCalculator();
  
  const handleSubmit = () => {
    calculateResults();
    setShowResults(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const handleReset = () => {
    resetForm();
    setShowResults(false);
  };
  
  return (
    <CalculatorLayout>
      {!showResults ? (
        <div className="animate-fadeIn">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
            Solar Panel Calculator
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Enter your details below to calculate your solar panel requirements, potential energy generation, and installation costs.
          </p>
          
          <CalculatorForm 
            onSubmit={handleSubmit} 
          />
        </div>
      ) : (
        <div className="animate-fadeIn">
          <CalculatorResults onReset={handleReset} />
        </div>
      )}
    </CalculatorLayout>
  );
};

export default CalculatorPage;