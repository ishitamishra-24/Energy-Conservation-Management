import React from 'react';
import { Link } from 'react-router-dom';
import { Sun, Users, Award, Clock, ArrowRight } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="pt-20 flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-teal-700 to-teal-900 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About SolarCalc</h1>
            <p className="text-xl leading-relaxed text-teal-100 mb-8">
              We're on a mission to make solar energy accessible to everyone by providing accurate, 
              user-friendly tools that help you make informed decisions about sustainable energy.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Story</h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                SolarCalc was founded in 2023 by a team of renewable energy enthusiasts who saw a gap in the market for accessible, easy-to-use solar calculation tools.
              </p>
              <p className="text-gray-600 mb-4 leading-relaxed">
                We noticed that while many people were interested in solar energy, they were often overwhelmed by complex technical details and unclear cost estimates. We set out to change that.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Today, our calculator has helped thousands of property owners around the world make informed decisions about their solar energy investments, contributing to a more sustainable future for all.
              </p>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/9875441/pexels-photo-9875441.jpeg" 
                  alt="Solar Panels Team"
                  className="w-full h-auto transform transition-transform duration-500 hover:scale-105"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose SolarCalc</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our calculator stands out from the competition for many reasons.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<Sun className="h-10 w-10 text-teal-500" />}
              title="Accuracy"
              description="Our calculations are based on the latest solar energy data and verified methodologies."
            />
            <FeatureCard 
              icon={<Users className="h-10 w-10 text-teal-500" />}
              title="User-Friendly"
              description="Simple interface designed for everyone, not just solar experts."
            />
            <FeatureCard 
              icon={<Award className="h-10 w-10 text-teal-500" />}
              title="Comprehensive"
              description="Get complete information on panels, energy, costs, and environmental impact."
            />
            <FeatureCard 
              icon={<Clock className="h-10 w-10 text-teal-500" />}
              title="Fast Results"
              description="Get your solar calculations in seconds, not days or weeks."
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Find answers to common questions about our calculator and solar energy.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <FAQItem 
              question="How accurate are the calculator results?"
              answer="Our calculator provides estimates based on industry-standard formulas and regional data. While the results are highly accurate for planning purposes, final installation details should always be confirmed with a professional solar installer."
            />
            <FAQItem 
              question="Does the calculator account for local rebates and incentives?"
              answer="Our cost estimates are based on average installation costs for your region. Local rebates, tax credits, and incentives can significantly reduce your costs, and we recommend checking with local authorities or solar installers for specific programs in your area."
            />
            <FAQItem 
              question="Can I use the calculator for commercial properties?"
              answer="Yes! Our calculator works for residential, commercial, industrial properties, and restaurants. Simply select your building type and enter the appropriate surface area."
            />
            <FAQItem 
              question="How does the calculator determine how many solar panels I need?"
              answer="We calculate the number of panels based on your available surface area, the average size of standard solar panels, and typical spacing requirements for optimal installation and maintenance access."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20 bg-teal-700 text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Go Solar?
          </h2>
          <p className="text-xl text-teal-100 mb-8 max-w-3xl mx-auto">
            Use our calculator to get started on your solar journey today.
          </p>
          <Link 
            to="/calculator"
            className="inline-flex items-center px-8 py-4 bg-white text-teal-700 font-bold rounded-lg shadow-lg hover:bg-yellow-300 hover:text-teal-800 transition duration-300 transform hover:scale-105"
          >
            Try Our Calculator <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg p-6 shadow-md border border-gray-100 hover:shadow-lg transition duration-300 transform hover:-translate-y-1">
      <div className="mb-4 inline-block p-3 bg-teal-50 rounded-full">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

interface FAQItemProps {
  question: string;
  answer: string;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border-b border-gray-200 py-4">
      <button
        className="flex justify-between items-center w-full text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-lg font-medium text-gray-800">{question}</h3>
        <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
          <svg className="w-5 h-5 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
          </svg>
        </span>
      </button>
      <div className={`mt-2 text-gray-600 transition-all duration-300 overflow-hidden ${isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
        <p className="py-2">{answer}</p>
      </div>
    </div>
  );
};

export default AboutPage;