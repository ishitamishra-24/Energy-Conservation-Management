import React from 'react';
import { Link } from 'react-router-dom';
import { SunIcon, Lightbulb, DollarSign, AreaChart, ArrowRight } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="pt-28 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-teal-600 via-teal-700 to-teal-900 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4 animate-fadeIn">
                Calculate Your <span className="text-yellow-300">Solar Potential</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-100 mb-8 leading-relaxed">
                Discover how much energy you can generate, how many panels you need, and the cost of installation based on your specific location and building type.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link 
                  to="/calculator" 
                  className="btn-primary inline-flex items-center justify-center"
                >
                  Start Calculating <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <Link 
                  to="/about" 
                  className="btn-secondary inline-flex items-center justify-center"
                >
                  Learn More
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="relative">
                <div className="absolute -inset-1 rounded-lg opacity-75 bg-gradient-to-r from-yellow-400 via-yellow-300 to-teal-300 blur"></div>
                <img 
                  src="https://images.pexels.com/photos/356036/pexels-photo-356036.jpeg" 
                  alt="Solar Panels" 
                  className="relative rounded-lg shadow-2xl max-w-full h-auto object-cover transform transition-transform duration-500 hover:scale-105"
                  style={{ maxHeight: '400px' }} 
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              What Our Calculator Provides
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Make informed decisions about solar energy with our comprehensive calculator that provides accurate estimates tailored to your needs.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<SunIcon className="h-10 w-10 text-teal-500" />}
              title="Panel Requirements"
              description="Calculate exactly how many solar panels you need based on your available surface area and energy goals."
            />
            <FeatureCard 
              icon={<Lightbulb className="h-10 w-10 text-teal-500" />}
              title="Energy Generation"
              description="Estimate how much energy your solar system can produce based on your location's sunlight hours."
            />
            <FeatureCard 
              icon={<DollarSign className="h-10 w-10 text-teal-500" />}
              title="Installation Costs"
              description="Get region-specific cost estimates for materials, installation, and potential incentives."
            />
            <FeatureCard 
              icon={<AreaChart className="h-10 w-10 text-teal-500" />}
              title="Environmental Impact"
              description="See your potential carbon footprint reduction and environmental benefits of going solar."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our calculator provides accurate estimates in just a few simple steps.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <StepCard 
              number="1"
              title="Enter Your Details"
              description="Provide your building type, surface area, and location to get started."
            />
            <StepCard 
              number="2"
              title="Customize Parameters"
              description="Adjust variables like roof angle and average sunlight hours for precise calculations."
            />
            <StepCard 
              number="3"
              title="Review Results"
              description="Get detailed estimates of panels needed, energy production, costs, and savings."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20 bg-teal-700 text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Discover Your Solar Potential?
          </h2>
          <p className="text-xl text-teal-100 mb-8 max-w-3xl mx-auto">
            Join thousands of property owners who have used our calculator to make informed decisions about solar energy.
          </p>
          <Link 
            to="/calculator"
            className="inline-block px-8 py-4 bg-white text-teal-700 font-bold rounded-lg shadow-lg hover:bg-yellow-300 hover:text-teal-800 transition duration-300 transform hover:scale-105"
          >
            Start Your Calculation Now
          </Link>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg p-6 shadow-md border border-gray-100 hover:shadow-lg transition duration-300 transform hover:-translate-y-1">
      <div className="mb-4 inline-block p-3 bg-teal-50 rounded-full">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

interface StepCardProps {
  number: string;
  title: string;
  description: string;
}

const StepCard: React.FC<StepCardProps> = ({ number, title, description }) => {
  return (
    <div className="bg-white rounded-lg p-6 shadow-md relative border border-gray-100 hover:shadow-lg transition duration-300">
      <div className="absolute -top-5 -left-5 bg-teal-600 text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold shadow-lg">
        {number}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default HomePage;